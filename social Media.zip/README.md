# Website about social Media structure
A basic website ehich showcases the content of our sicial media class, aswell as some contact info and a portfolio

> Not supposed to be used in any production environment, only for educational purposes

## Project structure

This file includes a website with some basic information about me as an illustration Artist and a cv, a small portfolio and a brief summary of the content we learnt in our social media class.